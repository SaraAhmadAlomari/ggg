*This activity has been created as part of the 42 curriculum by gmagable.*

# Inception

## Description
Inception sets up a small web infrastructure with Docker Compose inside a virtual machine.
Three services, each in its own container built from our own Dockerfiles (base: `debian:bookworm`, the penultimate stable Debian):

- **nginx** – the only entrypoint, port 443, TLSv1.2/TLSv1.3 only.
- **wordpress** – WordPress + php-fpm (no web server inside).
- **mariadb** – the database (nothing else).

Two named volumes (database and website files) store their data in `/home/gmagable/data`.
All containers share a dedicated Docker bridge network and restart automatically after a crash.

## Instructions
```bash
make          # create secrets, .env, data dirs, hosts entry, then build & start
make down     # stop and remove containers
make clean    # also remove volumes and local images
make fclean   # full cleanup (including /home/gmagable/data)
make re       # fclean + all
```
Then open `https://gmagable.42.fr` (accept the self-signed certificate).
See `USER_DOC.md` and `DEV_DOC.md` for details.

## Resources
- Docker docs: https://docs.docker.com/ (Compose, volumes, secrets, networking)
- Dockerfile best practices: https://docs.docker.com/build/building/best-practices/
- NGINX docs: https://nginx.org/en/docs/ and ngx_http_ssl_module
- WordPress / WP-CLI: https://developer.wordpress.org/cli/commands/
- PHP-FPM: https://www.php.net/manual/en/install.fpm.php
- MariaDB: https://mariadb.com/kb/en/documentation/
- PID 1 & signals in containers (Docker docs, `exec` form)

**AI usage:** AI was used to review the subject requirements, draft a first version of the Dockerfiles, entrypoint scripts and documentation, and explain Docker concepts (PID 1, named volumes, secrets, TLS). All generated content was reviewed, tested and understood by me, and discussed with peers before submission.

## Project description
Sources: `Makefile` (entry point), `srcs/docker-compose.yml`, `srcs/.env` (non-secret config),
`secrets/` (passwords, git-ignored), and `srcs/requirements/{mariadb,nginx,wordpress}` (Dockerfile + conf + tools).

Design choices:
- Base image `debian:bookworm` (penultimate stable), never `latest`.
- Entry scripts end with `exec` so the real daemon is PID 1 and gets signals; no hacky infinite-loop commands.
- MariaDB is initialised with `mariadbd --bootstrap` (no temporary background server).
- WordPress waits for MariaDB through a `healthcheck` + `depends_on: service_healthy`.
- Certificate is self-signed, generated at first start.

### Virtual Machines vs Docker
A VM virtualises hardware and runs a full OS with its own kernel: heavy, slow to start, strongly isolated.
Docker containers share the host kernel and isolate processes: light, fast, reproducible, but weaker isolation.

### Secrets vs Environment Variables
Environment variables are easy but visible via `docker inspect` and process environments.
Docker secrets are mounted as files in `/run/secrets/` and are not exposed in the image or inspect output.
We use `.env` for non-sensitive values and secrets for all passwords.

### Docker Network vs Host Network
A user-defined bridge network gives isolation, DNS by service name (`mariadb`, `wordpress`) and only published ports are reachable.
Host network removes isolation and shares the host's network stack (forbidden here).

### Docker Volumes vs Bind Mounts
Named volumes are managed by Docker (portable, listed with `docker volume ls`). Bind mounts map a host path directly and depend on the host layout.
Here we use named volumes whose `driver_opts` point to `/home/gmagable/data`, so we get named volumes **and** data on the host.
