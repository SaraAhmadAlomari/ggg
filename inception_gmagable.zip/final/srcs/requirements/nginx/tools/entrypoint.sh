#!/bin/sh
set -e

sed -i "s/DOMAIN_NAME_PLACEHOLDER/${DOMAIN_NAME}/g" /etc/nginx/nginx.conf

if [ ! -f /etc/nginx/ssl/inception.crt ]; then
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/nginx/ssl/inception.key \
        -out /etc/nginx/ssl/inception.crt \
        -subj "/C=FR/O=42/CN=${DOMAIN_NAME}"
fi

# nginx becomes PID 1 (daemon off = foreground)
exec nginx -g "daemon off;"
