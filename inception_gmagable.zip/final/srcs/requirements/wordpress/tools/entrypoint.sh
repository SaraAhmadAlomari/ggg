#!/bin/sh
set -e

DB_PASS="$(cat /run/secrets/db_password)"
ADMIN_PASS="$(cat /run/secrets/wp_admin_password)"
USER_PASS="$(cat /run/secrets/wp_user_password)"

wp() { php -d memory_limit=512M /usr/local/bin/wp --allow-root "$@"; }

cd /var/www/html

# First start only (MariaDB is already healthy thanks to depends_on)
if [ ! -f wp-config.php ]; then
    wp core download
    wp config create \
        --dbname="${MYSQL_DATABASE}" \
        --dbuser="${MYSQL_USER}" \
        --dbpass="${DB_PASS}" \
        --dbhost="mariadb:3306"
    wp core install \
        --url="https://${DOMAIN_NAME}" \
        --title="${WP_TITLE}" \
        --admin_user="${WP_ADMIN_USER}" \
        --admin_password="${ADMIN_PASS}" \
        --admin_email="${WP_ADMIN_EMAIL}" \
        --skip-email
    wp user create "${WP_USER}" "${WP_USER_EMAIL}" \
        --user_pass="${USER_PASS}" --role=author
fi

chown -R www-data:www-data /var/www/html
mkdir -p /run/php

# php-fpm becomes PID 1 (-F = foreground)
exec php-fpm8.2 -F
