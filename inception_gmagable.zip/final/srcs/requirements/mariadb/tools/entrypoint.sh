#!/bin/sh
set -e

DB_PASS="$(cat /run/secrets/db_password)"
ROOT_PASS="$(cat /run/secrets/db_root_password)"

mkdir -p /run/mysqld
chown -R mysql:mysql /run/mysqld /var/lib/mysql

# First start only: create system tables, database and users
# (bootstrap mode runs the SQL and exits, no background server needed)
if [ ! -d "/var/lib/mysql/${MYSQL_DATABASE}" ]; then
    if [ ! -d /var/lib/mysql/mysql ]; then
        mariadb-install-db --user=mysql --datadir=/var/lib/mysql \
            --auth-root-authentication-method=normal --skip-test-db > /dev/null
    fi

    cat > /tmp/init.sql <<SQL
FLUSH PRIVILEGES;
ALTER USER 'root'@'localhost' IDENTIFIED BY '${ROOT_PASS}';
CREATE DATABASE IF NOT EXISTS \`${MYSQL_DATABASE}\`;
CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'%' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${MYSQL_DATABASE}\`.* TO '${MYSQL_USER}'@'%';
FLUSH PRIVILEGES;
SQL
    mariadbd --user=mysql --bootstrap < /tmp/init.sql
    rm -f /tmp/init.sql
fi

# mariadbd becomes PID 1 (foreground, receives signals)
exec mariadbd --user=mysql
