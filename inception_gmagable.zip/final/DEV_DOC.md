# Developer documentation

## Prerequisites
Linux VM with Docker + Docker Compose plugin, `make`, `openssl`, `sudo`.

## Setup from scratch
`make setup` (run automatically by `make`) will:
1. create `/home/gmagable/data/{mariadb,wordpress}`;
2. create `srcs/.env` from `srcs/.env.example` (replacing `gmagable`);
3. generate random passwords in `secrets/`;
and `make hosts` adds `127.0.0.1 gmagable.42.fr` to `/etc/hosts`.
Edit `srcs/.env` / `secrets/` before the first run if you want other values.

## Build and launch
```bash
make            # docker compose -f srcs/docker-compose.yml up -d --build
make re         # rebuild everything from zero
```

## Useful commands
```bash
docker compose -f srcs/docker-compose.yml ps
docker compose -f srcs/docker-compose.yml logs -f nginx
docker exec -it mariadb mariadb -u root -p
docker volume ls
docker volume inspect srcs_mariadb_data
docker network ls
```

## Data and persistence
Named volumes `mariadb_data` and `wordpress_data` use the `local` driver with `type: none, o: bind`,
`device: ${DATA_PATH}/...`, so the data lives in `/home/gmagable/data/mariadb` and `/home/gmagable/data/wordpress`.
It survives `make down` and reboots; only `make fclean` deletes it.
