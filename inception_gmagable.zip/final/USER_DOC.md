# User documentation

## Services
- **nginx** – HTTPS entrypoint (port 443, TLS 1.2/1.3).
- **wordpress** – the website (WordPress + php-fpm).
- **mariadb** – the database used by WordPress.

## Start / stop
```bash
make          # start (builds if needed)
make stop     # pause containers
make start    # resume
make down     # stop and remove containers (data is kept)
```

## Access
- Website: `https://gmagable.42.fr`
- Admin panel: `https://gmagable.42.fr/wp-admin`
(The certificate is self-signed: accept the browser warning.)

## Credentials
- Non-secret settings (usernames, domain): `srcs/.env`
- Passwords: `secrets/*.txt` (`wp_admin_password.txt`, `wp_user_password.txt`, `db_password.txt`, `db_root_password.txt`)
- WordPress administrator: `boss_owner`. Second user (author): `writer_user`. Their passwords are in `secrets/wp_admin_password.txt` and `secrets/wp_user_password.txt`.
These files are git-ignored. To change a password, edit the file and run `make fclean && make`.

## Check that everything runs
```bash
make status                      # all 3 containers "Up" (mariadb "healthy")
make logs                        # live logs
curl -k -I https://gmagable.42.fr   # expect HTTP 200/301
```
